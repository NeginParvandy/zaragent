from __future__ import annotations

import asyncio
import re
from typing import Any

from app.application.services.action_service import ActionService
from app.application.services.daily_brief_service import DailyBriefService
from app.application.services.food_service import FoodService
from app.application.services.hr_service import HrService
from app.application.services.leave_balance_formatter import format_leave_balance_reply
from app.application.services.intent_guard import IntentGuard
from app.core.exceptions import AppError
from app.domain.models import AgentContext
from app.domain.text import (
    extract_jalali_dates,
    extract_times,
    hours_between,
    normalize_persian_text,
    parse_bool,
    parse_int,
    validate_jalali_range,
)
from app.infrastructure.repositories.state_repository import StateRepository


FOOD_RESTAURANT_CONFIRM_STATE = "food_restaurant_confirmation"
FOOD_RESTAURANT_SELECT_STATE = "food_restaurant_selection"
FOOD_CHAT_STATE_TTL_MINUTES = 10
FOOD_MEAL_ID = 1


class ChatService:
    def __init__(
        self,
        food: FoodService,
        hr: HrService,
        actions: ActionService,
        daily_brief: DailyBriefService,
        repository: StateRepository,
    ):
        self.food = food
        self.hr = hr
        self.actions = actions
        self.daily_brief = daily_brief
        self.repository = repository
        self.intent_guard = IntentGuard()

    async def handle(
        self,
        context: AgentContext,
        message: str,
    ) -> dict[str, Any]:
        text = normalize_persian_text(message)

        # INTENT_GUARD_PHASE1
        intent_decision = self.intent_guard.analyze(
            text
        )

        if not intent_decision.allowed:
            return intent_decision.to_response()

        pending_state_response = await self._handle_pending_chat_state(
            context,
            text,
        )
        if pending_state_response is not None:
            return pending_state_response

        pending_action_response = (
            await self._handle_pending_action_reply(
                context,
                text,
            )
        )
        if pending_action_response is not None:
            return pending_action_response

        try:
            dates = extract_jalali_dates(text)
            times = extract_times(text)
        except ValueError as exc:
            raise AppError(
                str(exc),
                code="INVALID_DATE_OR_TIME",
            ) from exc

        if self._is_help(text):
            return self._help_response()

        if self._is_daily_brief(text):
            data = await self.daily_brief.build(context)
            return {
                "reply": (
                    data.get("summary")
                    or "گزارش روزانه آماده شد."
                ),
                "requiresConfirmation": False,
                "data": data,
            }

        if self._is_food(text):
            return await self._handle_food(
                context,
                text,
                dates,
            )

        if self._is_leave_balance(text):
            data = await self.hr.get_time_account(
                context,
                dates[0] if dates else str(context.date),
            )

            rows = data.get("data", data)

            return {
                "reply": format_leave_balance_reply(rows),
                "requiresConfirmation": False,
                "data": rows,
            }

        if self._is_leave_list(text):
            target_date = (
                dates[0]
                if dates
                else str(context.date)
            )
            data = await self.hr.get_leave_requests(
                context,
                target_date,
            )
            rows = data.get("data") or []
            return {
                "reply": (
                    f"{len(rows) if isinstance(rows, list) else 0} "
                    "درخواست برای بازه موردنظر دریافت شد."
                ),
                "requiresConfirmation": False,
                "data": {
                    "date": target_date,
                    "requests": (
                        rows
                        if isinstance(rows, list)
                        else []
                    ),
                },
            }

        if self._is_delete_leave(text):
            return await self._prepare_delete_leave(
                context,
                text,
                dates,
            )

        if self._is_leave_create(text):
            return await self._prepare_create_leave(
                context,
                text,
                dates,
                times,
            )

        if self._is_attendance(text):
            return await self._handle_attendance(
                context,
                text,
                dates,
                times,
            )

        if self._is_greeting(text):
            name = (
                f" {context.display_name}"
                if context.display_name
                else ""
            )
            return {
                "reply": (
                    f"سلام{name}. آماده‌ام امور غذا، مرخصی، "
                    "مأموریت و تردد را برایت بررسی کنم."
                ),
                "requiresConfirmation": False,
                "suggestions": self._suggestions(),
            }

        return {
            "reply": (
                "درخواست را دقیق‌تر بگو. می‌توانم منوی غذا، "
                "رزرو و لغو غذا، مانده و درخواست‌های مرخصی، "
                "مأموریت، تردد و گزارش امروز را مدیریت کنم."
            ),
            "requiresConfirmation": False,
            "suggestions": self._suggestions(),
        }

    async def _handle_pending_action_reply(
        self,
        context: AgentContext,
        text: str,
    ) -> dict[str, Any] | None:
        reply_kind = (
            self._pending_action_reply_kind(text)
        )

        if reply_kind is None:
            return None

        employee_id = str(
            context.employee_id or ""
        ).strip()

        if not employee_id:
            raise AppError(
                "کد پرسنلی کاربر مشخص نیست.",
                code="MISSING_EMPLOYEE_ID",
            )

        pending_action = await asyncio.to_thread(
            self.repository.get_latest_pending_action,
            employee_id,
        )

        if pending_action is None:
            return {
                "reply": (
                    "در حال حاضر عملیاتی در انتظار "
                    "تأیید یا لغو ندارید."
                ),
                "requiresConfirmation": False,
                "data": {
                    "pendingAction": None,
                },
            }

        if reply_kind == "confirm":
            result = await self.actions.confirm(
                context,
                pending_action.id,
            )

            return {
                "reply": self._action_success_reply(
                    pending_action.action_type
                ),
                "requiresConfirmation": False,
                "action": {
                    "id": pending_action.id,
                    "type": (
                        pending_action.action_type
                    ),
                    "status": (
                        result.get("status")
                        or "succeeded"
                    ),
                },
                "data": result.get(
                    "result",
                    result,
                ),
            }

        result = await self.actions.cancel(
            context,
            pending_action.id,
        )

        current_status = result.get(
            "currentStatus"
        )

        if not current_status:
            current_status = (
                "cancelled"
                if result.get("cancelled")
                else "not_cancelled"
            )

        return {
            "reply": (
                result.get("message")
                or "عملیات لغو شد."
            ),
            "requiresConfirmation": False,
            "action": {
                "id": pending_action.id,
                "type": (
                    pending_action.action_type
                ),
                "status": current_status,
            },
            "data": result,
        }

    @staticmethod
    def _pending_action_reply_kind(
        text: str,
    ) -> str | None:
        normalized = normalize_persian_text(
            text
        )

        normalized = re.sub(
            r"[،,؛;.!؟?]+",
            " ",
            normalized,
        )

        normalized = re.sub(
            r"\s+",
            " ",
            normalized,
        ).strip()

        confirm_phrases = {
            "بله",
            "اره",
            "آره",
            "اوکی",
            "باشه",
            "تایید",
            "تأیید",
            "تایید میکنم",
            "تأیید میکنم",
            "تایید می کنم",
            "تأیید می کنم",
            "انجام بده",
            "ادامه بده",
            "بله انجام بده",
            "بله تایید میکنم",
            "بله تأیید میکنم",
            "بله لطفا",
            "بله لطفاً",
            "yes",
            "ok",
            "confirm",
        }

        cancel_phrases = {
            "نه",
            "خیر",
            "لغو",
            "لغو کن",
            "بیخیال",
            "بی خیال",
            "انصراف",
            "نمیخوام",
            "نمی خواهم",
            "نمیخوامش",
            "no",
            "cancel",
        }

        if normalized in confirm_phrases:
            return "confirm"

        if normalized in cancel_phrases:
            return "cancel"

        return None

    @staticmethod
    def _action_success_reply(
        action_type: str,
    ) -> str:
        messages = {
            "RESERVE_FOOD": (
                "رزرو غذا با موفقیت انجام شد."
            ),
            "CANCEL_FOOD": (
                "رزرو غذا با موفقیت لغو شد."
            ),
            "RATE_FOOD": (
                "امتیاز غذا با موفقیت ثبت شد."
            ),
            "CREATE_LEAVE": (
                "درخواست با موفقیت ثبت شد."
            ),
            "DELETE_LEAVE": (
                "درخواست با موفقیت حذف شد."
            ),
            "CREATE_TIME_EVENT": (
                "تردد با موفقیت ثبت شد."
            ),
        }

        return messages.get(
            action_type,
            "عملیات با موفقیت انجام شد.",
        )

    async def _handle_pending_chat_state(
        self,
        context: AgentContext,
        text: str,
    ) -> dict[str, Any] | None:
        employee_id = str(
            context.employee_id or ""
        ).strip()

        if not employee_id:
            return None

        state = await asyncio.to_thread(
            self.repository.get_chat_state,
            employee_id,
        )

        if not state:
            return None

        state_type = str(
            state.get("stateType") or ""
        ).strip()
        payload = state.get("payload") or {}

        if not isinstance(payload, dict):
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return None

        if state_type not in {
            FOOD_RESTAURANT_CONFIRM_STATE,
            FOOD_RESTAURANT_SELECT_STATE,
        }:
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return None

        restaurants = payload.get("restaurants") or []
        restaurants = [
            item
            for item in restaurants
            if isinstance(item, dict)
            and parse_int(item.get("restaurantId"))
        ]

        if not restaurants:
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return None

        if self._is_negative_reply(text):
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return {
                "reply": "درخواست انتخاب رستوران لغو شد.",
                "requiresConfirmation": False,
            }

        selected_restaurant = self._match_restaurant_reply(
            text,
            restaurants,
        )

        if (
            state_type == FOOD_RESTAURANT_CONFIRM_STATE
            and selected_restaurant is None
            and self._is_positive_reply(text)
        ):
            selected_restaurant = restaurants[0]

        if selected_restaurant is not None:
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return await self._resume_food_request(
                context,
                payload,
                selected_restaurant,
            )

        if self._looks_like_new_request(text):
            await asyncio.to_thread(
                self.repository.delete_chat_state,
                employee_id,
            )
            return None

        if state_type == FOOD_RESTAURANT_CONFIRM_STATE:
            restaurant = restaurants[0]
            return {
                "reply": (
                    f"رستوران مجاز شما "
                    f"«{restaurant.get('restaurantName')}» است. "
                    "برای ادامه فقط «بله» یا «خیر» بفرستید."
                ),
                "requiresConfirmation": False,
                "data": {
                    "awaitingRestaurantConfirmation": True,
                    "restaurant": restaurant,
                },
            }

        return {
            "reply": self._restaurant_selection_prompt(
                restaurants
            ),
            "requiresConfirmation": False,
            "data": {
                "awaitingRestaurantSelection": True,
                "restaurants": restaurants,
            },
        }

    async def _resume_food_request(
        self,
        context: AgentContext,
        payload: dict[str, Any],
        restaurant: dict[str, Any],
    ) -> dict[str, Any]:
        restaurant_id = parse_int(
            restaurant.get("restaurantId")
        )

        if restaurant_id is None:
            raise AppError(
                "شناسه رستوران انتخاب‌شده معتبر نیست.",
                code="INVALID_RESTAURANT",
            )

        original_message = str(
            payload.get("originalMessage")
            or "منوی غذا را نشان بده"
        )
        original_text = normalize_persian_text(
            original_message
        )

        target_date = payload.get("targetDate")
        context_date = payload.get("contextDate")

        context_updates: dict[str, Any] = {
            "restaurant_id": restaurant_id,
            "meal_id": FOOD_MEAL_ID,
        }

        if context_date:
            context_updates["date"] = context_date

        food_context = context.model_copy(
            update=context_updates
        )

        dates = (
            [str(target_date)]
            if target_date
            else []
        )

        return await self._handle_food(
            food_context,
            original_text,
            dates,
            restaurant_validated=True,
            selected_restaurant=restaurant,
        )

    async def _begin_restaurant_selection(
        self,
        context: AgentContext,
        text: str,
        target_date: str | None,
    ) -> dict[str, Any]:
        employee_id = str(
            context.employee_id or ""
        ).strip()

        if not employee_id:
            raise AppError(
                "کد پرسنلی کاربر برای دریافت رستوران‌ها مشخص نیست.",
                code="MISSING_EMPLOYEE_ID",
            )

        restaurants = await self.food.get_my_restaurants(
            context
        )

        if not restaurants:
            return {
                "reply": (
                    "برای شما رستوران مجازی تعریف نشده است. "
                    "لطفاً با واحد مربوطه تماس بگیرید."
                ),
                "requiresConfirmation": False,
                "data": {
                    "restaurants": [],
                },
            }

        state_payload = {
            "originalMessage": text,
            "targetDate": target_date,
            "contextDate": context.date,
            "restaurants": restaurants,
        }

        if len(restaurants) == 1:
            restaurant = restaurants[0]

            await asyncio.to_thread(
                self.repository.save_chat_state,
                employee_id,
                FOOD_RESTAURANT_CONFIRM_STATE,
                state_payload,
                FOOD_CHAT_STATE_TTL_MINUTES,
            )

            return {
                "reply": (
                    f"رستوران مجاز شما "
                    f"«{restaurant.get('restaurantName')}» است. "
                    "منوی همین رستوران را بررسی کنم؟"
                ),
                "requiresConfirmation": False,
                "data": {
                    "awaitingRestaurantConfirmation": True,
                    "restaurant": restaurant,
                    "expiresInMinutes": (
                        FOOD_CHAT_STATE_TTL_MINUTES
                    ),
                },
            }

        await asyncio.to_thread(
            self.repository.save_chat_state,
            employee_id,
            FOOD_RESTAURANT_SELECT_STATE,
            state_payload,
            FOOD_CHAT_STATE_TTL_MINUTES,
        )

        return {
            "reply": self._restaurant_selection_prompt(
                restaurants
            ),
            "requiresConfirmation": False,
            "data": {
                "awaitingRestaurantSelection": True,
                "restaurants": restaurants,
                "expiresInMinutes": (
                    FOOD_CHAT_STATE_TTL_MINUTES
                ),
            },
        }

    @staticmethod
    def _restaurant_selection_prompt(
        restaurants: list[dict[str, Any]],
    ) -> str:
        lines = [
            "شما به چند رستوران دسترسی دارید. "
            "لطفاً شماره یا نام رستوران موردنظر را بفرستید:"
        ]

        for index, restaurant in enumerate(
            restaurants,
            start=1,
        ):
            restaurant_name = (
                restaurant.get("restaurantName")
                or "رستوران بدون نام"
            )
            lines.append(
                f"{index}. {restaurant_name}"
            )

        return "\n".join(lines)

    @staticmethod
    def _match_restaurant_reply(
        text: str,
        restaurants: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        normalized_text = normalize_persian_text(
            text
        ).strip()

        compact_text = re.sub(
            r"\s+",
            " ",
            normalized_text,
        )

        for restaurant in restaurants:
            restaurant_name = normalize_persian_text(
                str(
                    restaurant.get("restaurantName")
                    or ""
                )
            ).strip()

            if not restaurant_name:
                continue

            short_name = restaurant_name.replace(
                "رستوران",
                "",
            ).strip()

            if (
                restaurant_name == compact_text
                or restaurant_name in compact_text
                or (
                    len(short_name) >= 3
                    and short_name in compact_text
                )
            ):
                return restaurant

        numbers = [
            parse_int(value)
            for value in re.findall(
                r"\d+",
                compact_text,
            )
        ]
        numbers = [
            value
            for value in numbers
            if value is not None
        ]

        for number in numbers:
            for restaurant in restaurants:
                if (
                    parse_int(
                        restaurant.get("restaurantId")
                    )
                    == number
                ):
                    return restaurant

        for number in numbers:
            if 1 <= number <= len(restaurants):
                return restaurants[number - 1]

        return None

    @staticmethod
    def _is_positive_reply(text: str) -> bool:
        normalized = normalize_persian_text(
            text
        ).strip()

        positive_phrases = {
            "بله",
            "اره",
            "آره",
            "اوکی",
            "باشه",
            "تایید",
            "تأیید",
            "ادامه بده",
            "بررسی کن",
            "انجام بده",
        }

        return any(
            phrase == normalized
            or phrase in normalized
            for phrase in positive_phrases
        )

    @staticmethod
    def _is_negative_reply(text: str) -> bool:
        normalized = normalize_persian_text(
            text
        ).strip()

        negative_phrases = {
            "خیر",
            "نه",
            "لغو",
            "بیخیال",
            "بی خیال",
            "انصراف",
            "نمیخوام",
            "نمی خواهم",
            "نمیخوامش",
        }

        return any(
            phrase == normalized
            or phrase in normalized
            for phrase in negative_phrases
        )

    def _looks_like_new_request(
        self,
        text: str,
    ) -> bool:
        return (
            self._is_help(text)
            or self._is_daily_brief(text)
            or self._is_food(text)
            or self._is_leave_balance(text)
            or self._is_leave_list(text)
            or self._is_delete_leave(text)
            or self._is_leave_create(text)
            or self._is_attendance(text)
            or self._is_greeting(text)
        )

    @staticmethod
    def _is_help(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "راهنما",
                "کمک",
                "چه کار",
                "قابلیت",
                "چی بلدی",
            ]
        )

    @staticmethod
    def _is_greeting(text: str) -> bool:
        return text in {
            "سلام",
            "درود",
            "سلام خوبی",
            "صبح بخیر",
            "عصر بخیر",
            "شب بخیر",
        }

    @staticmethod
    def _is_daily_brief(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "گزارش امروز",
                "خلاصه امروز",
                "وضعیت امروز",
                "گزارش روزانه",
            ]
        )

    @staticmethod
    def _is_food(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "غذا",
                "منو",
                "ناهار",
                "شام",
                "رزرو خوراک",
            ]
        )

    @staticmethod
    def _is_leave_balance(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "مانده مرخصی",
                "سهمیه مرخصی",
                "موجودی مرخصی",
            ]
        )

    @staticmethod
    def _is_leave_list(text: str) -> bool:
        read_words = [
            "نمایش",
            "نشان",
            "لیست",
            "ببین",
            "وضعیت",
            "درخواست های",
            "درخواست‌های",
        ]
        leave_words = [
            "مرخصی",
            "ماموریت",
            "مأموریت",
        ]
        mutation_words = [
            "ثبت",
            "حذف",
            "لغو",
            "کنسل",
            "بزن",
        ]
        return (
            any(
                word in text
                for word in read_words
            )
            and any(
                word in text
                for word in leave_words
            )
            and not any(
                word in text
                for word in mutation_words
            )
        )

    @staticmethod
    def _is_delete_leave(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "حذف",
                "کنسل",
                "لغو",
            ]
        ) and any(
            keyword in text
            for keyword in [
                "مرخصی",
                "ماموریت",
                "مأموریت",
                "درخواست",
            ]
        )

    @staticmethod
    def _is_leave_create(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "مرخصی",
                "ماموریت",
                "مأموریت",
                "اضافه کاری",
                "اضافه‌کاری",
            ]
        ) and any(
            keyword in text
            for keyword in [
                "ثبت",
                "درخواست",
                "بزن",
            ]
        )

    @staticmethod
    def _is_attendance(text: str) -> bool:
        return any(
            keyword in text
            for keyword in [
                "تردد",
                "ورود",
                "خروج",
                "ساعت زنی",
                "ساعت‌زنی",
            ]
        )

    async def _handle_food(
        self,
        context: AgentContext,
        text: str,
        dates: list[str],
        *,
        restaurant_validated: bool = False,
        selected_restaurant: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        target_date = (
            dates[0]
            if dates
            else context.date
        )

        if any(
            keyword in text
            for keyword in [
                "امتیاز",
                "ستاره",
                "نظر غذا",
                "نظر برای غذا",
            ]
        ):
            return await self._prepare_food_rating(
                context,
                text,
            )

        if not restaurant_validated:
            return await self._begin_restaurant_selection(
                context,
                text,
                target_date,
            )

        restaurant_data = (
            selected_restaurant
            or {
                "restaurantId": context.restaurant_id,
                "restaurantName": "",
            }
        )

        if any(
            keyword in text
            for keyword in [
                "حذف",
                "لغو",
                "کنسل",
            ]
        ):
            return await self._prepare_cancel_food(
                context,
                target_date,
                restaurant_data,
            )

        if any(
            keyword in text
            for keyword in [
                "رزرو من",
                "چی رزرو",
                "غذای رزرو",
                "وضعیت رزرو",
            ]
        ):
            menu = await self.food.get_weekly_menu(
                context
            )
            selected = [
                {
                    "date": day.get("date"),
                    "selectedPlanDetailId": (
                        day.get(
                            "selectedPlanDetailId"
                        )
                    ),
                    "foods": (
                        day.get("foods") or []
                    ),
                }
                for day in menu.get("days") or []
                if day.get("selectedPlanDetailId")
                and (
                    not target_date
                    or day.get("date") == target_date
                )
            ]
            return {
                "reply": (
                    f"{len(selected)} رزرو فعال پیدا شد."
                    if selected
                    else (
                        "رزرو فعالی برای تاریخ "
                        "موردنظر پیدا نشد."
                    )
                ),
                "requiresConfirmation": False,
                "data": {
                    "restaurant": restaurant_data,
                    "reservations": selected,
                },
            }

        reservation_intent = any(
            keyword in text
            for keyword in [
                "رزرو",
                "برام بگیر",
                "برایم بگیر",
                "ثبت غذا",
                "سفارش بده",
            ]
        )

        recommendation_intent = any(
            keyword in text
            for keyword in [
                "پیشنهاد",
                "چی بخور",
                "چه بخور",
                "بهترین غذا",
                "انتخاب مناسب",
            ]
        )

        menu_intent = any(
            keyword in text
            for keyword in [
                "منو",
                "نشان بده",
                "نمایش",
                "لیست",
                "چه غذایی",
                "غذاها",
            ]
        )

        if (
            menu_intent
            and not reservation_intent
            and not recommendation_intent
        ):
            menu = await self.food.get_weekly_menu(
                context
            )
            days = menu.get("days") or []

            if target_date:
                days = [
                    day
                    for day in days
                    if day.get("date") == target_date
                ]

            return {
                "reply": (
                    f"منوی {len(days)} روز دریافت شد."
                ),
                "requiresConfirmation": False,
                "data": {
                    **menu,
                    "restaurant": restaurant_data,
                    "days": days,
                },
            }

        if (
            recommendation_intent
            and not reservation_intent
        ):
            recommendation = (
                await self.food.recommend_food(
                    context,
                    target_date,
                )
            )

            if recommendation.get(
                "alreadyReserved"
            ):
                current = (
                    recommendation[
                        "alreadyReserved"
                    ][0]
                )
                return {
                    "reply": (
                        f"برای {current.get('date')} "
                        "قبلاً غذا رزرو شده است."
                    ),
                    "requiresConfirmation": False,
                    "data": {
                        **recommendation,
                        "restaurant": (
                            restaurant_data
                        ),
                    },
                }

            recommendations = (
                recommendation.get(
                    "recommendations"
                )
                or []
            )

            return {
                "reply": (
                    "پیشنهاد غذا آماده شد."
                    if recommendations
                    else (
                        "برای تاریخ موردنظر غذای "
                        "دارای ظرفیت پیدا نشد."
                    )
                ),
                "requiresConfirmation": False,
                "data": {
                    **recommendation,
                    "restaurant": restaurant_data,
                },
            }

        if not reservation_intent:
            menu = await self.food.get_weekly_menu(
                context
            )
            return {
                "reply": (
                    "منوی غذا دریافت شد. برای رزرو بگو "
                    "«برای امروز غذا پیشنهاد بده و رزرو کن»."
                ),
                "requiresConfirmation": False,
                "data": {
                    **menu,
                    "restaurant": restaurant_data,
                },
            }

        recommendation = (
            await self.food.recommend_food(
                context,
                target_date,
            )
        )

        if recommendation.get("alreadyReserved"):
            current = (
                recommendation["alreadyReserved"][0]
            )
            return {
                "reply": (
                    f"برای {current.get('date')} قبلاً "
                    "غذا رزرو شده است. ابتدا رزرو فعلی "
                    "را مشاهده یا لغو کنید."
                ),
                "requiresConfirmation": False,
                "data": {
                    **current,
                    "restaurant": restaurant_data,
                },
            }

        recommendations = (
            recommendation.get(
                "recommendations"
            )
            or []
        )

        if not recommendations:
            return {
                "reply": (
                    "برای تاریخ موردنظر غذای دارای "
                    "ظرفیت پیدا نشد."
                ),
                "requiresConfirmation": False,
                "data": {
                    "date": target_date,
                    "restaurant": restaurant_data,
                },
            }

        first = recommendations[0]
        food = first["food"]
        plan_detail_id = food.get(
            "planDetailId"
        )

        if not plan_detail_id:
            raise AppError(
                "شناسه غذای پیشنهادی از API دریافت نشد.",
                code="MISSING_PLAN_DETAIL",
            )

        action_payload = {
            "planDetailId": plan_detail_id,
            "restaurantId": context.restaurant_id,
            "mealId": (
                context.meal_id
                or FOOD_MEAL_ID
            ),
        }

        action = (
            await self.actions.create_pending_action(
                str(context.employee_id),
                "RESERVE_FOOD",
                action_payload,
            )
        )

        return {
            "reply": first["message"],
            "requiresConfirmation": True,
            "pendingAction": {
                "id": action["id"],
                "label": "تأیید و رزرو غذا",
                "expiresAt": action.get(
                    "expiresAt"
                ),
            },
            "data": {
                "date": first.get("date"),
                "food": food,
                "restaurant": restaurant_data,
                "mealId": (
                    context.meal_id
                    or FOOD_MEAL_ID
                ),
            },
        }

    async def _prepare_cancel_food(
        self,
        context: AgentContext,
        target_date: str | None,
        restaurant: dict[str, Any],
    ) -> dict[str, Any]:
        menu = await self.food.get_weekly_menu(
            context
        )

        for day in menu.get("days") or []:
            if (
                target_date
                and day.get("date") != target_date
            ):
                continue

            selected = day.get(
                "selectedPlanDetailId"
            )

            if selected:
                action_payload = {
                    "planDetailId": selected,
                    "restaurantId": (
                        context.restaurant_id
                    ),
                    "mealId": (
                        context.meal_id
                        or FOOD_MEAL_ID
                    ),
                }

                action = (
                    await self.actions
                    .create_pending_action(
                        str(context.employee_id),
                        "CANCEL_FOOD",
                        action_payload,
                    )
                )

                return {
                    "reply": (
                        f"حذف رزرو غذا برای "
                        f"{day.get('date')} آماده شد. "
                        "پس از تأیید، حذف واقعی "
                        "انجام می‌شود."
                    ),
                    "requiresConfirmation": True,
                    "pendingAction": {
                        "id": action["id"],
                        "label": (
                            "تأیید و حذف رزرو غذا"
                        ),
                        "expiresAt": action.get(
                            "expiresAt"
                        ),
                    },
                    "data": {
                        "date": day.get("date"),
                        "selectedPlanDetailId": (
                            selected
                        ),
                        "restaurant": restaurant,
                    },
                }

        return {
            "reply": (
                "برای تاریخ گفته‌شده رزرو غذایی "
                "پیدا نشد."
            ),
            "requiresConfirmation": False,
            "data": {
                "date": target_date,
                "restaurant": restaurant,
            },
        }

    async def _prepare_food_rating(
        self,
        context: AgentContext,
        text: str,
    ) -> dict[str, Any]:
        rate_match = re.search(
            r"امتیاز\s*[:：]?\s*([1-5])"
            r"(?:\s*از\s*5)?",
            text,
        )

        if rate_match is None:
            rate_match = re.search(
                r"([1-5])\s*ستاره",
                text,
            )

        rate = (
            parse_int(rate_match.group(1))
            if rate_match
            else None
        )

        if rate is None:
            return {
                "reply": (
                    "امتیاز را بین ۱ تا ۵ وارد کنید؛ "
                    "مثلاً «به غذای آخر ۵ ستاره بده»."
                ),
                "requiresConfirmation": False,
            }

        reserve_match = re.search(
            r"(?:رزرو|شناسه)\s*(\d+)",
            text,
        )
        reserve_id = (
            parse_int(reserve_match.group(1))
            if reserve_match
            else None
        )

        history = await self.food.get_history(
            context
        )

        if reserve_id is None:
            reserve_id = next(
                (
                    parse_int(
                        item.get("reserveId")
                    )
                    for item in history
                    if parse_int(
                        item.get("reserveId")
                    )
                ),
                None,
            )

        if reserve_id is None:
            return {
                "reply": (
                    "رزرو قابل امتیازدهی پیدا نشد."
                ),
                "requiresConfirmation": False,
            }

        comment_match = re.search(
            r"(?:نظر|کامنت)\s*[:：]?\s*(.+)$",
            text,
        )
        comment = (
            comment_match.group(1).strip()
            if comment_match
            else ""
        )

        action = (
            await self.actions.create_pending_action(
                str(context.employee_id),
                "RATE_FOOD",
                {
                    "reserveId": reserve_id,
                    "rate": rate,
                    "comment": comment,
                    "isAnonymous": (
                        "ناشناس" in text
                    ),
                },
            )
        )

        return {
            "reply": (
                f"ثبت امتیاز {rate} از ۵ برای "
                f"رزرو {reserve_id} آماده شد. "
                "تأیید می‌کنید؟"
            ),
            "requiresConfirmation": True,
            "pendingAction": {
                "id": action["id"],
                "label": "تأیید و ثبت امتیاز",
                "expiresAt": action.get(
                    "expiresAt"
                ),
            },
        }

    async def _prepare_delete_leave(
        self,
        context: AgentContext,
        text: str,
        dates: list[str],
    ) -> dict[str, Any]:
        target_date = (
            dates[0]
            if dates
            else context.date
        )

        if not target_date:
            return {
                "reply": (
                    "برای حذف درخواست، تاریخ "
                    "را وارد کنید."
                ),
                "requiresConfirmation": False,
            }

        leave_response = (
            await self.hr.get_leave_requests(
                context,
                target_date,
            )
        )
        rows = leave_response.get("data") or []

        if (
            not isinstance(rows, list)
            or not rows
        ):
            return {
                "reply": (
                    "برای این تاریخ درخواستی "
                    "پیدا نشد."
                ),
                "requiresConfirmation": False,
                "data": {
                    "date": target_date,
                },
            }

        leave_types = await self.hr.get_leave_types(
            context
        )
        type_rows = leave_types.get("data") or []

        matched = self.hr.find_leave_type(
            (
                type_rows
                if isinstance(type_rows, list)
                else []
            ),
            text,
        )

        candidates = rows

        if matched:
            candidates = [
                row
                for row in rows
                if str(
                    row.get(
                        "absenceTypeCode"
                    )
                )
                == str(
                    matched.get(
                        "absenceTypeCode"
                    )
                )
            ]

        deletable = [
            row
            for row in candidates
            if isinstance(row, dict)
            and parse_bool(
                row.get("isDeletable")
            )
        ]

        if len(deletable) != 1:
            return {
                "reply": (
                    "یک درخواست قابل حذف و یکتا "
                    "پیدا نشد. ردیف دقیق را از "
                    "پنل درخواست‌ها انتخاب کنید."
                ),
                "requiresConfirmation": False,
                "data": {
                    "candidateCount": (
                        len(candidates)
                    ),
                    "deletableCount": (
                        len(deletable)
                    ),
                },
            }

        row = deletable[0]

        payload = {
            "requestID": row.get("requestID"),
            "changeStateID": row.get(
                "changeStateID"
            ),
            "leaveKey": row.get("leaveKey"),
        }

        if (
            not payload["requestID"]
            or not payload["leaveKey"]
        ):
            raise AppError(
                "اطلاعات درخواست برای حذف کامل نیست.",
                code="INVALID_DELETE_REQUEST",
            )

        action = (
            await self.actions.create_pending_action(
                str(context.employee_id),
                "DELETE_LEAVE",
                payload,
            )
        )

        return {
            "reply": (
                f"حذف درخواست "
                f"«{row.get('absenceTypeName') or 'درخواست'}» "
                "آماده شد. تأیید می‌کنید؟"
            ),
            "requiresConfirmation": True,
            "pendingAction": {
                "id": action["id"],
                "label": "تأیید و حذف درخواست",
                "expiresAt": action.get(
                    "expiresAt"
                ),
            },
            "data": {
                "requestID": row.get(
                    "requestID"
                ),
                "absenceTypeName": row.get(
                    "absenceTypeName"
                ),
                "status": (
                    row.get("statusTxt")
                    or row.get("statusID")
                ),
            },
        }

    async def _prepare_create_leave(
        self,
        context: AgentContext,
        text: str,
        dates: list[str],
        times: list[str],
    ) -> dict[str, Any]:
        target_dates = (
            dates
            or (
                [str(context.date)]
                if context.date
                else []
            )
        )

        if not target_dates:
            return {
                "reply": (
                    "برای ثبت درخواست، تاریخ "
                    "لازم است."
                ),
                "requiresConfirmation": False,
            }

        leave_types = await self.hr.get_leave_types(
            context
        )
        type_rows = leave_types.get("data") or []

        leave_type = self.hr.find_leave_type(
            (
                type_rows
                if isinstance(type_rows, list)
                else []
            ),
            text,
        )

        if not leave_type:
            return {
                "reply": (
                    "نوع درخواست را دقیق‌تر بگویید؛ "
                    "مانند مرخصی ساعتی، استحقاقی "
                    "یا مأموریت ساعتی."
                ),
                "requiresConfirmation": False,
            }

        is_partial = parse_bool(
            leave_type.get(
                "isAllowedDurationPartialDay"
            )
        )

        if is_partial and len(times) < 2:
            return {
                "reply": (
                    "برای درخواست ساعتی، ساعت "
                    "شروع و پایان لازم است."
                ),
                "requiresConfirmation": False,
            }

        start_date = target_dates[0]
        end_date = (
            target_dates[1]
            if len(target_dates) > 1
            else target_dates[0]
        )

        try:
            start_date, end_date = (
                validate_jalali_range(
                    start_date,
                    end_date,
                )
            )
            if is_partial:
                hours_between(
                    times[0],
                    times[1],
                )
        except ValueError as exc:
            raise AppError(
                str(exc),
                code="INVALID_LEAVE_RANGE",
            ) from exc

        payload = {
            "absenceTypeCode": (
                leave_type.get(
                    "absenceTypeCode"
                )
            ),
            "startDate": start_date,
            "endDate": end_date,
            "startTime": (
                times[0]
                if is_partial
                else ""
            ),
            "endTime": (
                times[1]
                if is_partial
                else ""
            ),
            "notes": "",
            "additionalValues": (
                self._extract_additional_values(
                    text,
                    leave_type,
                )
            ),
        }

        existing = (
            await self.hr.get_leave_requests(
                context,
                start_date,
            )
        )
        existing_rows = (
            existing.get("data") or []
        )

        action = (
            await self.actions.create_pending_action(
                str(context.employee_id),
                "CREATE_LEAVE",
                payload,
            )
        )

        warning = (
            " در این بازه درخواست دیگری وجود دارد "
            "و ممکن است هم‌پوشانی ایجاد شود."
            if existing_rows
            else ""
        )

        return {
            "reply": (
                f"ثبت "
                f"{leave_type.get('absenceTypeName') or 'درخواست'} "
                f"برای {start_date} آماده شد."
                f"{warning} تأیید می‌کنید؟"
            ),
            "requiresConfirmation": True,
            "pendingAction": {
                "id": action["id"],
                "label": "تأیید و ثبت درخواست",
                "expiresAt": action.get(
                    "expiresAt"
                ),
            },
            "data": {
                "prepared": payload,
                "existingRequestCount": (
                    len(existing_rows)
                    if isinstance(
                        existing_rows,
                        list,
                    )
                    else 0
                ),
            },
        }

    async def _handle_attendance(
        self,
        context: AgentContext,
        text: str,
        dates: list[str],
        times: list[str],
    ) -> dict[str, Any]:
        target_dates = (
            dates
            or (
                [str(context.date)]
                if context.date
                else []
            )
        )

        if (
            "ثبت" not in text
            and "بزن" not in text
        ):
            if not target_dates:
                return {
                    "reply": (
                        "برای بررسی تردد، تاریخ "
                        "را وارد کنید."
                    ),
                    "requiresConfirmation": False,
                }

            end_date = (
                target_dates[1]
                if len(target_dates) > 1
                else target_dates[0]
            )

            events = await self.hr.get_time_events(
                context,
                target_dates[0],
                end_date,
            )
            rows = events.get("data") or []

            return {
                "reply": (
                    f"{len(rows) if isinstance(rows, list) else 0} "
                    "تردد دریافت شد."
                ),
                "requiresConfirmation": False,
                "data": {
                    "events": rows,
                },
            }

        if not target_dates or not times:
            return {
                "reply": (
                    "برای ثبت تردد، تاریخ و "
                    "ساعت لازم است."
                ),
                "requiresConfirmation": False,
            }

        events = await self.hr.get_time_events(
            context,
            target_dates[0],
            target_dates[0],
        )
        rows = events.get("data") or []

        valid, existing = (
            self.hr.validate_time_event_distance(
                (
                    rows
                    if isinstance(rows, list)
                    else []
                ),
                times[0],
            )
        )

        if not valid:
            return {
                "reply": (
                    f"تردد {existing} برای همین روز "
                    "وجود دارد و فاصله کمتر از "
                    "یک دقیقه مجاز نیست."
                ),
                "requiresConfirmation": False,
            }

        payload = {
            "eventDate": target_dates[0],
            "eventTime": times[0],
            "note": "",
        }

        action = (
            await self.actions.create_pending_action(
                str(context.employee_id),
                "CREATE_TIME_EVENT",
                payload,
            )
        )

        return {
            "reply": (
                f"ثبت تردد برای {target_dates[0]} "
                f"ساعت {times[0]} آماده شد. "
                "تأیید می‌کنید؟"
            ),
            "requiresConfirmation": True,
            "pendingAction": {
                "id": action["id"],
                "label": "تأیید و ثبت تردد",
                "expiresAt": action.get(
                    "expiresAt"
                ),
            },
        }

    @staticmethod
    def _extract_additional_values(
        text: str,
        leave_type: dict[str, Any],
    ) -> dict[str, Any]:
        values: dict[str, Any] = {}
        definitions = (
            leave_type.get(
                "toAdditionalFieldsDefinition"
            )
            or {}
        ).get("results") or []

        for item in (
            definitions
            if isinstance(definitions, list)
            else []
        ):
            if not isinstance(item, dict):
                continue

            key = (
                item.get("fieldName")
                or item.get("fieldname")
                or item.get("name")
                or item.get("field")
            )
            label = (
                item.get("fieldLabel")
                or item.get("label")
                or item.get("title")
                or ""
            )

            if key and (
                "محل" in str(label)
                or str(key).upper()
                == "CUSTOMER02"
            ):
                match = re.search(
                    r"(?:محل|مکان)\s+([^،\n]+)",
                    text,
                )
                values[str(key)] = (
                    match.group(1).strip()
                    if match
                    else ""
                )
            elif key:
                values[str(key)] = ""

        return values

    @classmethod
    def _help_response(
        cls,
    ) -> dict[str, Any]:
        return {
            "reply": (
                "قابلیت‌ها: نمایش و رزرو غذا، لغو رزرو، "
                "امتیازدهی، مانده و درخواست‌های مرخصی، "
                "ثبت/حذف مرخصی و مأموریت، نمایش/ثبت "
                "تردد و گزارش روزانه. تمام عملیات "
                "تغییردهنده فقط بعد از تأیید اجرا می‌شوند."
            ),
            "requiresConfirmation": False,
            "suggestions": cls._suggestions(),
        }

    @staticmethod
    def _suggestions() -> list[str]:
        return [
            "منوی غذای امروز را نشان بده",
            "برای امروز غذا پیشنهاد بده و رزرو کن",
            "مانده مرخصی من چقدر است؟",
            "درخواست‌های مرخصی امروز را نشان بده",
            "ثبت مرخصی ساعتی امروز از 14:00 تا 17:00",
            "تردد امروز را نشان بده",
            "گزارش امروز من را بساز",
        ]